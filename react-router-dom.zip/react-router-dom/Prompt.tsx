import React from "react";

import RouterContext from "./Context";

interface Props {
  when: boolean;
  message: any;
}

export default class Prompt extends React.Component<Props> {
  static contextType = RouterContext;

  render() {
    const { when, message } = this.props;

    if (when) {
      this.context.history.block(message);
    } else {
      this.context.history.block(null);
    }

    return null;
  }
}
