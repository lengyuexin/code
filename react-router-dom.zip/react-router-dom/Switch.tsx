import React, { ReactElement } from "react";
import RouterContext from "./Context";
import { pathToRegexp, Key } from "path-to-regexp";

interface Props {
  children?: Array<ReactElement>;
}

export default class Switch extends React.Component<Props> {
  static contextType = RouterContext;

  //从context获取的路径与子组件进行匹配，
  //匹配到后续就不再匹配
  render() {
    let pathname = this.context.location.pathname;
    if (!this.props.children) return null;

    let children;

    children = Array.isArray(this.props.children)
      ? this.props.children
      : [this.props.children];

    for (let i = 0; i < children.length; i++) {
      let child = children[i];
      const { path = "/", exact = false } = child.props;
      let paramsName: Array<Key> = [];
      let regexp = pathToRegexp(path, paramsName, { end: exact });
      let res = pathname.match(regexp);
      
      if (res) return child;
    }

    return null;
  }
}
