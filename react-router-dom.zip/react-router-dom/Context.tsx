import {createContext} from 'react'
import {ContextValue} from './'

let RouterContext=createContext<ContextValue>({})


export default RouterContext