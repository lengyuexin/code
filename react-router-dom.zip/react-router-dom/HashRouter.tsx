import React, { ReactNode } from "react";
import { Location, LocationType } from "./history";
import RouterContext from "./Context";
import { ContextValue } from "./";

interface Props {
  children: ReactNode;
}

interface State {
  location: Location;
}

export default class HashRouter extends React.Component<Props, State> {
  LocationState: any;
  state = {
    location: {
      pathname: window.location.hash.slice(1),
    },
  };

  componentDidMount() {
    window.addEventListener("hashchange", (e: HashChangeEvent) => {
      this.setState({
        location: {
          ...this.state.location,
          pathname: window.location.hash.slice(1) || "/",
          state: this.LocationState,
        },
      });
    });

    window.location.hash = window.location.hash || "/";
  }

  render() {
    let that = this;

    let contextVal: ContextValue = {
      location: this.state.location,
      history: {
        push(to: LocationType) {
          if (this.message) {
            let flag = window.confirm(
              this.message(typeof to === "object" ? to.pathname : to)
            );

            if (!flag) return;
          }
          if (typeof to === "object") {
            window.location.hash = to.pathname;
            that.LocationState = to.state;
          } else {
            window.location.hash = to;
            that.LocationState = {};
          }
        },
        block(message) {
          this.message = message;
        },
      },
    };

    return (
      <RouterContext.Provider value={contextVal}>
        {this.props.children}
      </RouterContext.Provider>
    );
  }
}
