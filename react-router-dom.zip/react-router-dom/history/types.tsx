export interface Location<S = any> {
  pathname: string;
  state?: S;
}

export type LocationType = string | Location;

export interface History {
  push(to: LocationType): void;
  block(message: any): void;
  message?:any
}
