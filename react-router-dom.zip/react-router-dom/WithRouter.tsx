import React, { ComponentType } from "react";
import { Route, RouteComponentProps } from "./";

let WithRouter = (Component: ComponentType) => {
  //外层参数 如<App/>
  return (props: any) => {
    // 内层路由参数透传
    return (
      <Route
        render={(routeProps: RouteComponentProps) => (
          <Component {...routeProps} {...props} />
        )}
      />
    );
  };
};

export default WithRouter;


/***
 * 
 * let withRouter=(Component)=>{
 * 
 * 
 * return (props)=>{
 * 
 * 
 * return <Route render={(RouterProps)=>{
 * 
 * return <Component {...props} {...RouterProps}/>
 * }}/>
 * 
 * 
 * }
 * 
 * 
 * 
 * 
 * }
 * 
 * 
 * 
 * 
 */