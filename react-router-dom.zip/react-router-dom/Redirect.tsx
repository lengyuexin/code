import React, { PropsWithChildren } from "react";
import { LocationType } from "./history";
import RouterContext from "./Context";

type Props = PropsWithChildren<{
  to: LocationType;
}>;

export default class Redirect extends React.Component<Props> {
  static contextType = RouterContext;

  render() {
    this.context.history.push(this.props.to);
    return null;
  }
}
