import React, { PropsWithChildren, AnchorHTMLAttributes } from "react";
import { LocationType } from "./history";
import RouterContext from "./Context";

type Props = PropsWithChildren<{
  to: LocationType;
}>;

type Aprops = Props & AnchorHTMLAttributes<HTMLAnchorElement>;
export default class Link extends React.Component<Aprops> {
  static contextType = RouterContext;

  render() {
    return (
      <a
        className={this.props.className}
      
        onClick={() => {
        
          this.context.history.push(this.props.to);
        }}
      >
        {this.props.children}
      </a>
    );
  }
}
