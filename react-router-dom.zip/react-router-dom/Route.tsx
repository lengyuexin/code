import React, { ReactNode, JSXElementConstructor } from "react";
import RouterContext from "./Context";
import { pathToRegexp, Key } from "path-to-regexp";
import { Match, RouteComponentProps } from "./";
import { LocationType } from "./history";
interface Props {
  path?: LocationType;
  component?: JSXElementConstructor<any>;
  exact?: boolean;
  render?: (props: RouteComponentProps<any>) => ReactNode;
  children?: (props: RouteComponentProps<any>) => ReactNode;
}

//判断当前组件的path属性和浏览器路径是否一致
export default class Route extends React.Component<Props> {
  static contextType = RouterContext;

  render() {
    let {
      path = "/",
      component: RouteComponent,
      exact = false,
      render,
      children,
    } = this.props;

    let pathname = this.context.location.pathname;



    let keys: Array<Key> = [];
    let regexp = pathToRegexp(
      typeof path === "string" ? path : path.pathname,
      keys,
      { end: exact }
    );
    let res = pathname.match(regexp);

   

    //pathname='/user/1' path=/user/:id
    //res=['/user/1','1']
    let routeProps: RouteComponentProps = {
      location: this.context.location,
      history: this.context.history,
    };

    if (res) {
      let [url, ...values] = res; //url=/user/1 values=['1']

      let paramNames = keys.map((k: Key) => k.name); //['id']

      let memo: any = {};

      let params = values.reduce((memo: any, value: string, index: number) => {
        memo[paramNames[index]] = value;
        return memo;
      }, memo);

      let match: Match = {
        params: params,
        isExact: path === url,
        path: typeof path === "string" ? path : path.pathname,
        url: url,
      };

      routeProps.match = match;

     

      if (RouteComponent) {

        return <RouteComponent {...routeProps} />;
      } else if (render) {
        return render({ ...routeProps });
      } else if (children) {
        return children({ ...routeProps });
      } else {
        return null;
      }
    } else {
      if (children) {
        return children({ ...routeProps });
      }

      return null;
    }
  }
}
