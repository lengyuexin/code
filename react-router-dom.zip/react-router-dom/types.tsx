import { Location,History } from "./history";
export interface ContextValue {
  location?: Location;
  history?: History;
}

export interface Match<Params = {}> {
  params: Params;
  isExact: boolean;
  path: string;
  url: string;
}

export interface RouteComponentProps<Params = {}, S = any> {
  history: History;
  location: Location<S>;
  match?: Match<Params>;
}
