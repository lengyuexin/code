import React, { ComponentType } from "react";
import { Redirect, Route } from ".";

interface Props {
  path: string;
  component: ComponentType;
}

let Protected = (props: Props) => {
  let { path, component: RouteComponent } = props;

  //内部的权限逻辑是可以自定义的
  return (
    <Route
      path={path}
      render={(renderProps: any) => {
        if (window.localStorage.getItem("auth") === "success") {
          return <RouteComponent {...props} {...renderProps} />;
        } else {
          return <Redirect to="/" />;
        }
      }}
    />
  );
};

export default Protected;
