import React, { ReactNode } from "react";
import { Route, Link } from "./";
import { LocationType } from "./history";



interface Props {
  to: LocationType;
  exact?: boolean;
  children?: ReactNode;
}
//判断地址栏路径和to里的路径是否一致，一致则添加active类名
let NavLink = (props: Props) => {
  let { to, exact, children } = props;

  return (
    <Route
      path={to}
      exact={exact}
      children={(childrenProps: any) => {
        
        return (
          <Link
            className={childrenProps.match ? "active" : ""}
            to={to}
            {...childrenProps}
          >
            {children}
          </Link>
        );
      }}
    />
  );
};

export default NavLink;
