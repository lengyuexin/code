import React, { ReactNode } from "react";
import { Location, LocationType } from "./history";
import RouterContext from "./Context";
import { ContextValue } from "./";

interface Props {
  children: ReactNode;
}

interface State {
  location: Location;
}

declare global {
  interface Window {
    onpushstate: (state: any, pathname: string) => void;
    
  }
}
export default class BrowserRouter extends React.Component<Props, State> {
  LocationState: any;
  state = {
    location: {
      pathname: "/",
    },
  };

  componentDidMount() {
    //触发popstate的时候 会执行此函数
    window.onpopstate = (e: PopStateEvent) => {
      this.setState({
        location: {
          ...this.state.location,
          pathname: document.location.pathname,
          state: e.state,
        },
      });
    };

    //触发pushstate的时候 会执行此函数
    window.onpushstate = (state: any,pathname: string) => {
    
      this.setState({
        location: {
          ...this.state.location,
          pathname: pathname,
          state: state,
        },
      });
    };
    
  }

  render() {

    
    let contextVal: ContextValue = {
      location: this.state.location,
      history: {
        push(to: LocationType) {
          if (this.message) {
            let flag = window.confirm(
              this.message(typeof to === "object" ? to.pathname : to)
            );

            if (!flag) return;
          }
          if (typeof to === "object") {
            window.history.pushState(to.state, "", to.pathname);
          } else {
            window.history.pushState(null, "", to);
          }
        },
        block(message) {
          this.message = message;
        },
      },
    };

    return (
      <RouterContext.Provider value={contextVal}>
        {this.props.children}
      </RouterContext.Provider>
    );
  }
}
