import React from "react";
import bindActionCreators from "../redux/bindActionCreators";
import ReactReduxContext from "./Context";
export default function (mapStateToProps: any, mapDispatchToProps: any) {
  return function (OldComponent: any) {
    return class NewComponent extends React.Component {
      unsubscribe: any;
      static contextType = ReactReduxContext;
      constructor(props: any, context: any,updater:any) {
        super(props);

       
        this.state = mapStateToProps(context.store.getState());
      }

      componentDidMount() {
        this.unsubscribe = this.context.store.subscribe(() => {
          this.setState(mapStateToProps(this.context.store.getState()));
        });
      }

      componentWillUnmount() {
        this.unsubscribe();
      }

      render() {
        let actions;
        if (typeof mapDispatchToProps === "function") {
          actions = mapDispatchToProps(this.context.store.dispatch);
        } else if (
          mapDispatchToProps &&
          typeof mapDispatchToProps === "object"
        ) {
          actions = bindActionCreators(
            mapDispatchToProps,
            this.context.store.dispatch
          );
        }

        return <OldComponent {...this.state} {...actions} />;
      }
    };
  };
}
