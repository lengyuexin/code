import React from "react";
import { Store } from "redux";

export interface ContextValue {
  store: Store;
}

const context = React.createContext<ContextValue | null>(null);

export default context;
