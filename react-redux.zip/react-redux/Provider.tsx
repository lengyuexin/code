import React, { Component } from "react";
import { Store } from "redux";
import { AnyAction } from "../redux";

import ReactReduxContext from "./Context";

type Props = {
  store: Store<any, AnyAction>;
};

export default class Provider extends Component<Props> {
  render() {

   
    return (
      <ReactReduxContext.Provider
        value={{
          store: this.props.store,
        }}
      >
        {this.props.children}
      </ReactReduxContext.Provider>
    );
  }
}
