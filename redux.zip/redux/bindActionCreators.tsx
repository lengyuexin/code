function bindActionCreator(actionCreator: any, dispatch: any) {
  return function (...args: any) {
    return dispatch(actionCreator(...args));
  };
}

function bindActionCreators(actionCreators: any, dispatch: any) {
  if (typeof actionCreators === "function") {
    return bindActionCreator(actionCreators, dispatch);
  }
  interface O {
    [p: string]: any;
  }
  const boundActionCreators: O = {};
  for (const key in actionCreators) {
    const actionCreator = actionCreators[key];
    if (typeof actionCreator === "function") {
      boundActionCreators[key] = bindActionCreator(actionCreator, dispatch);
    }
  }
  return boundActionCreators;
}

export default bindActionCreators;
