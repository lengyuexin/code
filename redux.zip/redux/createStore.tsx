import {
  StoreCreator,
  Dispatch,
  Action,
  AnyAction,
  Reducer,
  Store,
  Listener,
  Unsubscribe,
  Subscribe,
} from "./index";

const createStore: StoreCreator = <S, A extends Action = AnyAction>(
  reducer: Reducer<S, A>,
  preloadState?: S | undefined
): Store<S, A> => {
  let currentState: S = preloadState as S;

  let currentListeners: Array<Listener> = [];

  function getState(): S {
    return currentState;
  }

  const dispatch: Dispatch<A> = (action: A) => {
    currentState = reducer(currentState, action);
    currentListeners.forEach((l) => l());
    return action;
  };

  // initState 初始状态树构建
  dispatch({ type:'INIT' } as A)
  const subscribe: Subscribe = (listener: Listener): Unsubscribe => {
    currentListeners.push(listener);

    return function () {
      let index = currentListeners.indexOf(listener);
      currentListeners.splice(index, 1);
    };
  };

  const store: Store<S, A> = {
    getState,
    dispatch,
    subscribe,
  };

  return store;
};

export default createStore;
