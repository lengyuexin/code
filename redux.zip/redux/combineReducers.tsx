export default function combineReducers(reducers: any) {
  return function (state: any, action: any) {
    const nextState: any = {};

    for (const key in reducers) {
      if (reducers.hasOwnProperty(key)) {
        let reducer = reducers[key];

        let preStateForKey = state[key]; // state.counter1
        let nextStateForKey = reducer(preStateForKey, action);
        nextState[key] = nextStateForKey;
      }
    }

    return nextState;
  };
}
