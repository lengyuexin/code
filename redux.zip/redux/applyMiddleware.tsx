import compose from "./compose";

export default function applyMiddleware(...middlewares: Array<any>) {
  return (createStore: any) => {
    return (...args: any) => {
      let store = createStore(...args);

      let dispatch: any = () => {};

      const middlewareAPI = {
        getState: store.getState,
        dispatch:(...args:any) => dispatch(...args),
      };

      const chain = middlewares.map((middleware) => middleware(middlewareAPI));
      dispatch = compose(...chain)(store.dispatch);

      return {
        ...store,
        dispatch,
      };
    };
  };
}
