export interface Action<T = string> {
  type: T;
}
export interface Listener {
  (): void;
}

export interface Dispatch<A extends Action = AnyAction> {
  (action: A): A;
}
export interface Unsubscribe {
  (): void;
}
// export interface GetState<S> {
//   (): S; 
// }
export interface Subscribe {
  (listener: Listener): Unsubscribe;
}
export interface Store<S = any, A extends Action = AnyAction> {
  dispatch: Dispatch<A>;
  getState(): S;
  subscribe: Subscribe;
}
export interface AnyAction extends Action {
  [p: string]: any;
}

// 接口 参数类型 返回值是: 修饰 type 是=>修饰

export interface Reducer<S = any, A extends Action = AnyAction> {
  (state: S | undefined, action: A): S;
}

export interface StoreCreator {
  <S, A extends Action = AnyAction>(
    reducer: Reducer<S, A>,
    preloadedState?: S
  ): Store<S, A>;
}

// import {StoreCreator} from 'redux'
