
const http = require('http')

const context = require('./context')
const request = require('./request')
const response = require('./response')
const EventEmitter = require('events')
const Stream = require('stream')

class Application extends EventEmitter {

    constructor() {
        super()
        this.context = context
        this.request = request
        this.response = response
        this.middlewares = []//多个use调用，存起来
    }

    //注册方法
    use(fn) {

        this.middlewares.push(fn)

    }
    createContext(req, res) {


        // url1: ctx.url,
        // url2: ctx.request.url,
        // url3: ctx.req.url,
        // url4: ctx.request.req.url,


        const context = Object.create(this.context)
        context.request = Object.create(this.request)
        context.response = Object.create(this.response)
        context.request.req = context.req = req
        context.response.res = context.res = res



        return context


    }

    compose(ctx) {

        let index = -1;//每个中间件next调用次数

        const dispatch = (i) => {
            //越界处理 下边还有then 不能直接return ，要返回promise

            // 正常调用下(一次)，index一直比i小1 

            if (i <= index) return Promise.reject(new Error('next() called multiple times'))

            //更新调用次数
            index = i;

            if (i === this.middlewares.length) return Promise.resolve()

            //获取当前的中间件 最开始是第一个
            const middleware = this.middlewares[i]

            // 中间件执行需要两个参数
            const exec = middleware(ctx, () => dispatch(++i))
            //有可能这个方法没有加async,包装一层
            //保证返回的是一个promise
            //这样handleRequest的then函数就不会报错

            try {
                return Promise.resolve(exec)
            } catch (err) {
                return Promise.reject(err)
            }


        }

        return dispatch(0)

    }

    handleRequest(req, res) {

        const ctx = this.createContext(req, res)

        //组合中间件 并执行返回后的promise
        // 获取到_body 响应出去


        this.compose(ctx).then(() => {
            //默认只能处理buffer 和string
            let _body = ctx.body;

            if (_body === '') {
                //如果没设置body 就给个默认值
                //状态码设置为404
                res.statusCode = 404
                _body = 'not found'
                return res.end(_body)
            } else if (_body instanceof Stream) {
                //对流的处理
                return _body.pipe(res)
            } else if (typeof _body !== 'null' && typeof _body === 'object') {
                //对对象的处理
                return res.end(JSON.stringify(_body))
            } else if (_body == null) {
                //null 和undefined 直接字符串形式输出
                //无法直接调用toString 可以拼接一下
                return res.end(_body + '')
            } else {
                //其他类型的直接toString 
                return res.end(_body.toString())
            }

        }).catch(err => {
            this.emit('error', err)
        })
    }

    //监听端口号
    listen(...args) {

        const server = http.createServer(this.handleRequest.bind(this))
        server.listen(...args)
       

    }

}

module.exports = Application