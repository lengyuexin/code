const context = {

}


function delegateGet(prop, key) {
    context.__defineGetter__(key, function () {
        return this[prop][key]
    })
}

function delegateSet(prop, key) {

    context.__defineSetter__(key, function (newValue) {
        this[prop][key] = newValue
    })
}

delegateGet('request', 'url')
delegateGet('request', 'method')
delegateGet('response', 'body')
delegateSet('response', 'body')
delegateGet('response', 'status')


module.exports = context