const response = {

    _body: '',

    get body() {
        return this._body
    },

    set body(newBody) {
        this._body = newBody
    },

    get status() {
        return this.res.statusCode
    },


}



module.exports = response