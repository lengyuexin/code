import * as glob from 'glob';
import path from 'path';
export default (folder: string, router: any) => {
  // 扫描指定文件夹下所有ts文件
  glob.sync(path.join(folder, '**/*.ts')).forEach(item => {
    // 加载controller
    const controller = require(item).default;
    // 实例化
    const instance: any = new controller();
    const { prefix } = instance;
    const routes = Reflect.get(controller, 'routes');
    routes.forEach(route => {
      router[route.requestMethod](prefix + route.path, ctx => {
        instance[route.methodName](ctx);
      });
    });
  });
};
