export const controller =
  (prefix = ''): ClassDecorator =>
    (target: any) => {
      target.prototype.prefix = prefix;
    };

type Method = 'get' | 'post' | 'delete' | 'options' | 'put' | 'head';

export interface RouteDefinition {
  path: string;
  requestMethod: Method;
  methodName: string;
}

const creatorFactory =
  (requestMethod: Method) =>
    (path: string): MethodDecorator =>
      (target, name) => {
        if (!Reflect.has(target.constructor, 'routes')) {
          Reflect.defineProperty(target.constructor, 'routes', {
            value: [],
          });
        }
        const routes = Reflect.get(target.constructor, 'routes');
        routes.push({
          requestMethod,
          path,
          methodName: name,
        });
      };

export const get = creatorFactory('get');
// export const post = creatorFactory('post');
// export const del = creatorFactory('delete');
// export const put = creatorFactory('put');
// export const options = creatorFactory('options');
// export const head = creatorFactory('head');
