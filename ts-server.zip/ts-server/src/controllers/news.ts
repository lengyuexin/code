import { controller, get } from '../decorator';

@controller('/news')
export default class NewsCtrl {
  @get('/index')
  async index(ctx) {
    ctx.body = 'hello news';
  }
}
