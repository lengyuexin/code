import { controller, get } from '../decorator';

@controller('/main')
export default class MainCtrl {
  @get('/index')
  async index(ctx) {
    ctx.body = 'hello world';
  }
  @get('/home')
  async home(ctx) {
    ctx.body = 'hello home';
  }
}
