export type Methods = "get" | "GET" | "post" | "POST" | "put" | "PUT";
export interface AxiosRequestConfig {
  url?: string;
  method?: Methods;
  params?: any;
  headers?: any;
  data?: any;
  timeout?: number;
  cancelToken?:any;
  isCancel?:any;
}

export interface AxiosInterceptorManager<V> {
  use(
    onFulfilled?: (value: V) => V | Promise<V>,
    onRejected?: (error: any) => any
  ): number;
  eject(id: number): void;
}

//promise的泛型T会代表成功态的resolve的值类型 resolve(value )
export interface AxiosInstance<T = any> {
  (config: AxiosRequestConfig): Promise<AxiosResponse<T>>;

  interceptor: {
    request: AxiosInterceptorManager<AxiosRequestConfig>;
    response: AxiosInterceptorManager<AxiosResponse<T>>;
  };

  CancelToken?:any;
  isCancel?:any;
}

//泛型T代表响应体的类型

export interface AxiosResponse<T> {
  data: T;
  status: number;
  statusText: string;
  headers?: Record<string, any>;
  config?: AxiosRequestConfig;
  request?: XMLHttpRequest;
}
