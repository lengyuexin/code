class Cancel {
  public msg: string = "";
  public __CANCEL__: boolean = true;
  constructor(msg: string) {
    this.msg = msg;
  }
}

export function isCancel(err: any) {
 
  return !!(err && err.__CANCEL__);
}
export class CancelToken {
  public resolve: any;

  source() {
    return {
      token: new Promise((resolve) => {
        this.resolve = resolve;
      }),
      cancel: (msg: string) => {
        this.resolve(new Cancel(msg));
      },
    };
  }
}
