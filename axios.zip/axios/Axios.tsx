import { AxiosRequestConfig, AxiosResponse } from "./types";
import qs from "qs";
import parseHeaders from "parse-headers";
import AxiosInterceptorManager, {
  Interceptor,
} from "./AxiosInterceptorManager";

export default class Axios<T> {
  public interceptor = {
    request: new AxiosInterceptorManager<AxiosRequestConfig>(),
    response: new AxiosInterceptorManager<AxiosResponse<T>>(),
  };

  //T 用来限制响应对象response里data的类型
  request(
    config: AxiosRequestConfig
  ): Promise<AxiosRequestConfig | AxiosResponse<T>> {
    const chain: Array<
      Interceptor<AxiosRequestConfig> | Interceptor<AxiosResponse<T>>
    > = [
      {
        onFulfilled: this.dispatchRequest,
        onRejected: (err) => err,
      },
    ];

    //向左侧添加请求拦截器

    this.interceptor.request.interceptors.forEach(
      (interceptor: Interceptor<AxiosRequestConfig> | null) => {
        interceptor && chain.unshift(interceptor);
      }
    );

    //向右侧添加响应拦截器

    this.interceptor.response.interceptors.forEach(
      (interceptor: Interceptor<AxiosResponse<T>> | null) => {
        interceptor && chain.push(interceptor);
      }
    );

    let promsie: any = Promise.resolve(config);

    while (chain.length) {
      const { onFulfilled, onRejected } = chain.shift()!;
      promsie = promsie.then(onFulfilled, onRejected);
    }

    return promsie;
    // return this.dispatchRequest(config);
  }

  dispatchRequest<T>(config: AxiosRequestConfig): Promise<AxiosResponse<T>> {
    return new Promise<AxiosResponse<T>>(function (resolve, reject) {
      let { method, url, params, headers, data, timeout } = config;

      let xhr = new XMLHttpRequest();
      xhr.responseType = "json";

      if (params && typeof params === "object") {
        params = qs.stringify(params);
      } else {
        params = "";
      }

      url += (url!.indexOf("?") === -1 ? "?" : "&") + params;
      xhr.open(method!, url!, true);

      xhr.onreadystatechange = function () {


        if( xhr.readyState === 4){
          if (xhr.status >= 200 && xhr.status < 300 ) {
            const res: AxiosResponse<T> = {
              config: config,
              data: xhr.response ? xhr.response : xhr.responseText,
              headers: parseHeaders(xhr.getAllResponseHeaders()),
              request: xhr,
              status: xhr.status,
              statusText: xhr.statusText,
            };
  
            resolve(res);
          } else if(xhr.status<200&&xhr.status!==0||xhr.status>400) {
           
            reject("Error: Request failed with status code " + xhr.status + "");
          }
  
        }
       

      };

      xhr.onerror = function () {
        reject("请求失败");
      };

      if (timeout) {
        xhr.ontimeout = function () {
          reject("Error: timeout of " + timeout + "ms exceeded");
        };
      }

      if (headers) {
        for (const key in headers) {
          if (Object.prototype.hasOwnProperty.call(headers, key)) {
            const element = headers[key];
            xhr.setRequestHeader(key, element);
          }
        }
      }

      let body: string | null = null;
      if (data) {
        body = JSON.stringify(data);
      }

      if (config.cancelToken) {
        config.cancelToken.then((msg: string) => {
          xhr.abort();
          console.log(msg)
          reject(msg);
        });
      }

      xhr.send(body);
    });
  }
}
