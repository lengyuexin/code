import Axios from "./Axios";
import {AxiosInstance} from './types'
import {CancelToken,isCancel} from './cancelToken'
export * from "./types";
function createInstance():AxiosInstance {
  let context = new Axios();

  //让原型上的request方法的this指向context
  let instance:any= Axios.prototype.request.bind(context);

  //将原型和context上的属性拷贝到instance上
  instance = Object.assign(instance, Axios.prototype, context);

  return instance as AxiosInstance;
}

let axios = createInstance();

axios.CancelToken=new CancelToken
axios.isCancel=isCancel
export default axios;



