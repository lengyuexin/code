const GetFileListPlugin  = require('./GetFileListPlugin.js')
const config = {

    entry: './index.js',
    output: {
        filename: 'bundle.js'
    },
    mode: 'development',
    module: {
        rules: [
            {
                test: /\.md$/,
                use: './md-loader'
            }
        ]
    },
    plugins: [new GetFileListPlugin ()]

}

module.exports = config
