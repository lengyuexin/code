class GetFileListPlugin {
    apply(compiler) {
        compiler.hooks.emit.tap('GetFileListPlugin ', compilation => {
            // compilation => 可以理解为此次打包的上下文
            for (const name in compilation.assets) {
                console.log(name)
                const contents = compilation.assets[name].source()
                compilation.assets[name] = {
                    //用于返回新内容 
                    source: () => contents,
                    //返回内容大小
                    size: () => noComments.length
                }
            }
        })

    }
}

module.exports = GetFileListPlugin