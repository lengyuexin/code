import article from './article.md'
import title from './title'

/**
 * 测试流程
 * 1. 安装相关依赖 npm i
 * 2. 进入文件夹内执行命令 webpack
 * 3. 打开浏览器，以本地路径加载index.html
 * 4. 页面展示loader处理后的html
 * 5. over
 */

 console.log(title)
document.body.innerHTML=article